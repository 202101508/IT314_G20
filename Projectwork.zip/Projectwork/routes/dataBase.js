const mongoose = require("mongoose");
const passportLocalMongoose = require("passport-local-mongoose");

const { Schema } = mongoose;

mongoose.connect("mongodb://127.0.0.1:27017/hostelEase");

//Records Schema
const recordSchema = new Schema({
	Id: Number,
	Status: String,
	Date: Date,
});

const Record = mongoose.model("Record", recordSchema);

//Fetching records
async function fetchRecords() {
	try {
		const records = await Record.find();
		return records;
	} catch (error) {
		throw error;
	}
}

//Inbox schema
const inboxSchema = new Schema({
	studName: String,
	studId: String,
	reasonForVisit: String,
});

const Inbox = mongoose.model("Inbox", inboxSchema);

//Student Details Schema
const studentDetailsSchema = new Schema({
	student_name: String,
	student_id: String,
	academic_year: String,
	batch: String,
	email: String,
	gender: String,
	blood_group: String,
	mobile_no: String,
});

const studDetailSchema = mongoose.model("studDetails", studentDetailsSchema);

//Fetching inbox
async function fetchInbox() {
	try {
		const inbox = await Inbox.find();
		return inbox;
	} catch (err) {
		throw err;
	}
}

//User schema
const userSchema = new Schema({
	username: String,
	email: String,
	password: String,
	isAdmin: String,
	studDetails: {
		type: mongoose.Schema.Types.ObjectId,
		ref: "studDetails",
	},
});

userSchema.plugin(passportLocalMongoose);
const User = mongoose.model("User", userSchema);

module.exports = {
	User,
	Record,
	Inbox,
	fetchInbox,
	fetchRecords,
	studDetailSchema,
};

const model = require("./data");

// model.addStudent(User.studDetails);

// model.addInbox(Inbox);
// model.addRecords(Record);
