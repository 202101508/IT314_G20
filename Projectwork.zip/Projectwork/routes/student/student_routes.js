const { addStudentDetails, updateStudentDetails } = require("../data");
var { User, studDetailSchema } = require("../dataBase");

//Student Routes
module.exports = (app, authenticateUser) => {
	app.get("/student/:uName/home", authenticateUser, (req, res) => {
		var username = req.params.uName;
		res.render("student/student_home", { username: username });
	});

	app.get(
		"/student/:uName/student_details",
		authenticateUser,
		async (req, res) => {
			var username = req.params.uName;
			try {
				const result = await User.findOne({ username: username }).populate(
					"studDetails"
				);

				if (result) {
					var resultStudentDetails = result.studDetails || {};
					console.log("User with studDetails:", resultStudentDetails);
					res.render("student/student_details", {
						data: resultStudentDetails,
						username: username,
					});
				} else {
					console.log("User not found.");
				}
			} catch (error) {
				console.error(error);
			}
		}
	);

	app.get(
		"/student/:uName/edit_student_details",
		authenticateUser,
		async (req, res) => {
			var username = req.params.uName;
			try {
				const result = await User.findOne({ username: username }).populate(
					"studDetails"
				);
				if (result) {
					var resultStudentDetails = result.studDetails || {};
					console.log("User with studDetails:", resultStudentDetails);
					res.render("student/edit_student_detail", {
						data: resultStudentDetails,
						username: username,
					});
				} else {
					console.log("User not found.");
				}

				console.log(result);
			} catch (error) {
				console.log(error);
			}
		}
	);

	app.post(
		"/student/:uName/edit_student_details",
		authenticateUser,
		async (req, res) => {
			const formData = req.body;
			// console.log(req.body);

			var username = req.params.uName;
			try {
				const result = await User.findOne({ username: username }).populate(
					"studDetails"
				);
				if (result) {
					if (result.studDetails) {
						console.log("update");
						updateStudentDetails(result.studDetails, formData);
					} else {
						console.log("Add");
						addStudentDetails(studDetailSchema, username, formData);
					}
					res.redirect(`/student/${req.params.uName}/student_details`);
				} else {
					console.log("User not found.");
				}

				console.log(result);
			} catch (error) {
				console.log(error);
			}
		}
	);

	app.get("/student/:uName/fee_receipt", authenticateUser, (req, res) => {
		var username = req.params.uName;
		res.render("student/fee_receipt", { username: username });
	});

	app.get("/student/:uName/req_box", authenticateUser, (req, res) => {
		var username = req.params.uName;
		res.render("student/req_box.ejs", { username: username });
	});

	app.get("/student/:uName/visitation", authenticateUser, (req, res) => {
		var username = req.params.uName;
		res.render("student/visitation", { username: username });
	});

	app.get(
		"/student/:uName/visitation/visitation_button",
		authenticateUser,
		(req, res) => {
			var username = req.params.uName;
			res.render("student/visitation_button", { username: username });
		}
	);

	app.get(
		"/student/:uName/req_box/req_box_button",
		authenticateUser,
		(req, res) => {
			var username = req.params.uName;
			res.render("student/req_box_button", { username: username });
		}
	);

	app.get(
		"/student/:uName/emergency_contacts",
		authenticateUser,
		(req, res) => {
			var username = req.params.uName;
			res.render("student/emergency_contacts", { username: username });
		}
	);
};
