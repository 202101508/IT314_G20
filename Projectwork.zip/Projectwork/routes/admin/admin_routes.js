module.exports = (app, authenticateUser) => {
	app.get("/admin/:uName/home", authenticateUser, (req, res) => {
		var username = req.params.uName;
		res.render("admin/home", {username: username});
	});

	app.get("/admin/:uName/emergency_contacts", authenticateUser, (req, res) => {
		var username = req.params.uName;
		res.render("admin/emergency_contacts", {username: username});
	});

	app.get("/admin/:uName/fee_receipt", authenticateUser, (req, res) => {
		var username = req.params.uName;
		res.render("admin/fee_receipt", {username: username});
	});

	app.get("/admin/:uName/req_box", authenticateUser, (req, res) => {
		var username = req.params.uName;
		res.render("admin/req_box_admin", {username: username});
	});

	app.get("/admin/:uName/req_box_records", authenticateUser, (req, res) => {
		var username = req.params.uName;
		res.render("admin/req_box_records", {username: username});
	});

	app.get("/admin/:uName/my_profile", authenticateUser, (req, res) => {
		var username = req.params.uName;
		res.render("admin/admin_details", {username: username});
	});

	app.get("/admin/:uName/edit_my_profile", authenticateUser, (req, res) => {
		var username = req.params.uName;
		// res.render("admin/edit_admin_details", {username: username});
		res.send("Hello");
	});

	app.get("/admin/:uName/vp_requests", authenticateUser, (req, res) => {
		var username = req.params.uName;
		res.render("admin/vp_requests", {username: username});
	});

	app.get("/admin/:uName/vp_records", authenticateUser, (req, res) => {
		var username = req.params.uName;
		res.render("admin/vp_records", {username: username});
	});

	app.get("/admin/:uName/help", authenticateUser, (req, res) => {
		var username = req.params.uName;
		res.render("admin/help", {username: username});
	});
};
